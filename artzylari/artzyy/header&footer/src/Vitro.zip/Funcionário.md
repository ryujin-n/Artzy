## Setor Financeiro

	- Diretor Financeiro.
	- Gerente Financeiro.
	- Supervisor Financeiro.
	- Analista Financeiro.
	- Auxiliar Financeiro.

## Setor Contábil

	- Contador.
	- Analista.
	- Auditor.
	- Consultor Financeiro.

## Setor de Logística

	- Coordenador de PCP.
	- Analista de logística.
	- Gerente de compras.
	- Gerente de Lógistica.

## Setor de Marketing 

	- Diretor de Marketing. 
	- Analista de Marketing.
	- Assistente de Marketing.
	- Coordenador de Marketing Digital.