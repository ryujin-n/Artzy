Os QCoins são moedas próprias da empresa, onde todas as transações entre clientes é feita. Seu principal objetivo é gerar economia entre clientes.
O QCoins pode ser adquirido com dinheiro real, depois de acumulado o usuário pode escolher manter os Tokens ou converter eles em moeda.

## Pacotes de QCoins

##### R$ 5,00 - 400 QCoins
##### R$ 10,00 - 800 QCoins
##### R$ 25,00 - 2000 QCoins
##### R$ 50,00 - 4000 QCoins
##### R$ 100,00 - 8000 QCoins





