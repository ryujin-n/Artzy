
- CreateQ é uma plataforma para artistas independentes encontrarem um lugar seguro e prático para realizarem as suas comissões, sem taxas, o ganho seria totalmente do artista e a plataforma lucraria a partir de uma forma de inscrição "Premium" que desbloquearia mais benefícios para o artista.



