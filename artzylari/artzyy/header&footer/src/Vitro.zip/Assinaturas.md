## Recursos Premium R$ 30,00 Mensais / R$ 80,00 Trimestral / R$ 250,00 Anual

-  GIF como foto de perfil e banner
- Badge de verificado
- Opção de desconto.
- 250 QCoins mensais.
- QBox com itens com base no seu trabalho.

## Recurso Creative R$ 50,00 Mensais / R$ 120,00 Trimestral / R$ 360,00 Anual

-  Customização Avançada do perfil
-  GIF como foto de perfil e banner
- Opções maiores de desconto (50%)
- 500 QCoins mensais
- QBox com itens do artista do mês
-  Badge personalizados ao lado do nome de usuário.