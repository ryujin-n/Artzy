
- Chat Cliente/Artista: Um lugar onde o cliente poderia entrar em contato diretamente com o artista para poder fazer revisões de seu pedido. 

- Lista de espera para o artista se organizar com listas de:

		- Pronto
		- Em espera
		- Em andamento

 Onde ele vai poder separar os pedidos de acordo com o seu status:

- Área para Portfolio: Uma área onde o artista pode colocar suas artes (Música, Scripts, Desenhos, Trailers, etc.) para poder mostrar para o público o seu trabalho.

- Amigos: Um recurso onde o artista ou o cliente pode ser amigo de outros clientes ou artistas, assim criando uma rede maior, possibilitando até colaborações entre artistas.

- QCoins próprio, para poder usar como forma alternativa de pagamento.

- Filtro de pesquisa por estilo/preferencias.

- Formas de pagamento pelo próprio site (incluindo QCoins).

- Artistas mais requisitados do mês ganham premium, e em colaboração como o site, ganha sua arte estampada em camisetas e blusa distribuídas no sistema de lootbox premium.

