### Nível Estratégico
Nessa área estão os profissionais que são responsáveis pelo planejamento do crescimento da empresa e tomada de decisões importantes.
A CreateQ é representada por quatro CEOs, sendo eles Miles, Nelson, Laricia e Heitor.

## Nível Tático
Nessa área estão os responsáveis pela tomada de decisões estratégicas com um plano tático. Aqui eles tem o controle de gerenciar e coordenar operações para os objetivos serem atingidos. Os responsáveis são: Contabilidade, Financeiro, Tesouraria, Consultor de vendas e compras.
## Nível Operacional
Aqui estão os profissionais responsáveis por colocar o plano e estratégias definidas pelos profissionais do Nível Tático. Nesse nível estão Estagiários e Funcionários em geral.

