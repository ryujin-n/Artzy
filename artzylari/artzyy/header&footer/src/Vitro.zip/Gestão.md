
Assim que o usuário entra no sistema, ele se encontra com a tela de acesso onde será requisitado as suas credenciais de acesso (Nome de usuário e Senha).
	ver [[Regras de Negócio]] de referência

## Login Empresarial

Logo quando os dados forem recolhidos, o funcionário se deparará com um dashboard com todos os dados de sua área.
	ver [[Nível Hierárquico]] de referência
	ver [[Funcionário]] de referência
### Financeiro

O usuário da área Financeira será responsável por todo o fluxo de caixa da empresa, isso inclui o fechamento com parcerias de marcas, as finanças e o fluxo de Tokens entre usuários Cliente.
	ver [[Parceria]] como referência
	ver [[QCoins]] como referência
	ver [[Finanças]] como referência
	
As Vendas e Compras também estão incluídas nesse quesito, o setor de Vendas cuida do sistema de distribuição das assinaturas, enquanto o de compras cuida da aquisição dos produtos das parcerias e fornecedores, compra de utilitários que chegam através de chamados com ordens de serviço.
	ver [[Ordem de Serviço]] como referência
	ver [[Assinaturas]] como referência
	ver [[Fornecedor]] como referência
	
O Contador cuida da parte da contabilidade e das finanças da empresa, administra o fluxo econômico dentro da empresa, todas as compras e vendas passam por ele e são autorizadas pelo mesmo, ele quem contabiliza os gastos geridos pelas ordens de serviço, já o Tesoureiro com o pagamento referente as [[Assinaturas]] .
	ver [[Contabilidade]] como referência

## Login Artista

O login do Artista é para aqueles que vendem seus serviços para seus próprios clientes, ele tem controle sobre o status de seus produtos (se está Pronto, em Andamento ou em Espera) e sobre a quantidade de QCoins que eles possuem.



