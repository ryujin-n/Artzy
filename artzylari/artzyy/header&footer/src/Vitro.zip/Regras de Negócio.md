
- Apenas usuários cadastrados da empresa podem acessar o sistema, cada usuário será vinculado com seu nível hierárquico.
- Assim que o usuário logar, ele será direcionado para o dashboard com as informações de seu nível hierárquico.
- Um usuário não pode ultrapassar as funções de sua hierarquia.