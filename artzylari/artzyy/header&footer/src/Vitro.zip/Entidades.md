
## Financeiro

	- Vendas.
	- Compras.
	- Contas.
	- Estoque.
	- Controle de produção.
	- Finanças.
	- Fornecedor.
	- Fluxo.
	- Contabilidade.
	- Parceria.
	- Tokens.


## Login

	- Usuário.
	- Nível hierarquico.


## Gestão de Dados

	- Funcionário.
	- Dados Empresariais.
	- Fluxo de dados.
	- Dashboard.
