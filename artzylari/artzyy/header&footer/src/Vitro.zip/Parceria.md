As parcerias são fechadas através de um contrato que tem como objetivo garantir a colaboração entre a CreateQ e as demais empresas. 
A parceria tem como principal objetivo a adição de produtos para distribuição em eventos. 
## Nossas parcerias são:
	- Kalunga.
	- Tilibra.
	- Faber Castell. 
	- Bic.
	- Wacom.
	- Huion.
A CreateQ escolheu fechar parceria com essas marcas porque são reconhecidas pela excelência em produtos relacionados a papelaria e artigos artísticos. Tendo essas marcas como parceiras, a CreateQ consegue oferecer uma variedade de produtos de alta qualidade aos clientes, abrangendo desde materiais básicos até ferramentas mais avançadas para expressão artística e produtividade. 