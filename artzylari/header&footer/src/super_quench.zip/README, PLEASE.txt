This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-quench/

Super Quench: A Font Full of Fun and Fizz!
Super Quench is a font that explodes with personality, playfully combining the bubbly charm of a classic bubble font with the bold impact of a strong, eye-catching design. It's perfect for adding a touch of whimsy and energy to your projects, whether it's a playful logo, a vibrant website header, or a quirky social media post