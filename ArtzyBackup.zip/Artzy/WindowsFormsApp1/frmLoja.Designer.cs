﻿namespace WindowsFormsApp1
{
    partial class frmLoja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLoja));
            this.kryptonPalette1 = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.pbClebio = new System.Windows.Forms.PictureBox();
            this.btoSair = new System.Windows.Forms.PictureBox();
            this.btoLoja = new System.Windows.Forms.PictureBox();
            this.btoHome = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.bto9 = new System.Windows.Forms.PictureBox();
            this.bto7 = new System.Windows.Forms.PictureBox();
            this.bto8 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.bto6 = new System.Windows.Forms.PictureBox();
            this.bto5 = new System.Windows.Forms.PictureBox();
            this.bto4 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bto3 = new System.Windows.Forms.PictureBox();
            this.bto2 = new System.Windows.Forms.PictureBox();
            this.bto1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btoConf = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbClebio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btoSair)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btoLoja)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btoHome)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bto9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto8)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bto6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto4)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bto3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btoConf)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonPalette1
            // 
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Rounding = 26;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Width = 3;
            // 
            // pbClebio
            // 
            this.pbClebio.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbClebio.BackgroundImage")));
            this.pbClebio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbClebio.Location = new System.Drawing.Point(11, 65);
            this.pbClebio.Name = "pbClebio";
            this.pbClebio.Size = new System.Drawing.Size(191, 88);
            this.pbClebio.TabIndex = 6;
            this.pbClebio.TabStop = false;
            // 
            // btoSair
            // 
            this.btoSair.BackColor = System.Drawing.Color.Transparent;
            this.btoSair.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btoSair.BackgroundImage")));
            this.btoSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btoSair.Location = new System.Drawing.Point(-73, 713);
            this.btoSair.Name = "btoSair";
            this.btoSair.Size = new System.Drawing.Size(191, 60);
            this.btoSair.TabIndex = 7;
            this.btoSair.TabStop = false;
            this.btoSair.Click += new System.EventHandler(this.btoSair_Click);
            this.btoSair.MouseEnter += new System.EventHandler(this.btoSair_MouseEnter);
            this.btoSair.MouseLeave += new System.EventHandler(this.btoSair_MouseLeave);
            // 
            // btoLoja
            // 
            this.btoLoja.BackColor = System.Drawing.Color.Transparent;
            this.btoLoja.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btoLoja.BackgroundImage")));
            this.btoLoja.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btoLoja.Location = new System.Drawing.Point(-73, 347);
            this.btoLoja.Name = "btoLoja";
            this.btoLoja.Size = new System.Drawing.Size(191, 60);
            this.btoLoja.TabIndex = 8;
            this.btoLoja.TabStop = false;
            this.btoLoja.MouseEnter += new System.EventHandler(this.btoLoja_MouseEnter);
            this.btoLoja.MouseLeave += new System.EventHandler(this.btoLoja_MouseLeave);
            // 
            // btoHome
            // 
            this.btoHome.BackColor = System.Drawing.Color.Transparent;
            this.btoHome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btoHome.BackgroundImage")));
            this.btoHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btoHome.Location = new System.Drawing.Point(-73, 215);
            this.btoHome.Name = "btoHome";
            this.btoHome.Size = new System.Drawing.Size(191, 60);
            this.btoHome.TabIndex = 9;
            this.btoHome.TabStop = false;
            this.btoHome.Click += new System.EventHandler(this.btoHome_Click);
            this.btoHome.MouseEnter += new System.EventHandler(this.btoHome_MouseEnter);
            this.btoHome.MouseLeave += new System.EventHandler(this.btoHome_MouseLeave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(208, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(987, 791);
            this.panel1.TabIndex = 10;
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel5.Controls.Add(this.bto9);
            this.panel5.Controls.Add(this.bto7);
            this.panel5.Controls.Add(this.bto8);
            this.panel5.Location = new System.Drawing.Point(134, 533);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(688, 235);
            this.panel5.TabIndex = 2;
            // 
            // bto9
            // 
            this.bto9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto9.BackgroundImage")));
            this.bto9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bto9.Location = new System.Drawing.Point(514, 164);
            this.bto9.Name = "bto9";
            this.bto9.Size = new System.Drawing.Size(100, 42);
            this.bto9.TabIndex = 0;
            this.bto9.TabStop = false;
            // 
            // bto7
            // 
            this.bto7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto7.BackgroundImage")));
            this.bto7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bto7.Location = new System.Drawing.Point(71, 164);
            this.bto7.Name = "bto7";
            this.bto7.Size = new System.Drawing.Size(100, 42);
            this.bto7.TabIndex = 0;
            this.bto7.TabStop = false;
            // 
            // bto8
            // 
            this.bto8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto8.BackgroundImage")));
            this.bto8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bto8.Location = new System.Drawing.Point(292, 164);
            this.bto8.Name = "bto8";
            this.bto8.Size = new System.Drawing.Size(100, 42);
            this.bto8.TabIndex = 0;
            this.bto8.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel3.Location = new System.Drawing.Point(-1, 51);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(280, 65);
            this.panel3.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel6.Controls.Add(this.bto6);
            this.panel6.Controls.Add(this.bto5);
            this.panel6.Controls.Add(this.bto4);
            this.panel6.Location = new System.Drawing.Point(490, 127);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(319, 322);
            this.panel6.TabIndex = 0;
            // 
            // bto6
            // 
            this.bto6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto6.BackgroundImage")));
            this.bto6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bto6.Location = new System.Drawing.Point(198, 164);
            this.bto6.Name = "bto6";
            this.bto6.Size = new System.Drawing.Size(87, 50);
            this.bto6.TabIndex = 0;
            this.bto6.TabStop = false;
            // 
            // bto5
            // 
            this.bto5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto5.BackgroundImage")));
            this.bto5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bto5.Location = new System.Drawing.Point(113, 164);
            this.bto5.Name = "bto5";
            this.bto5.Size = new System.Drawing.Size(88, 58);
            this.bto5.TabIndex = 0;
            this.bto5.TabStop = false;
            // 
            // bto4
            // 
            this.bto4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto4.BackgroundImage")));
            this.bto4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bto4.Location = new System.Drawing.Point(29, 164);
            this.bto4.Name = "bto4";
            this.bto4.Size = new System.Drawing.Size(88, 58);
            this.bto4.TabIndex = 0;
            this.bto4.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel2.Controls.Add(this.bto3);
            this.panel2.Controls.Add(this.bto2);
            this.panel2.Controls.Add(this.bto1);
            this.panel2.Location = new System.Drawing.Point(165, 127);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(319, 322);
            this.panel2.TabIndex = 0;
            // 
            // bto3
            // 
            this.bto3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto3.BackgroundImage")));
            this.bto3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bto3.Location = new System.Drawing.Point(204, 172);
            this.bto3.Name = "bto3";
            this.bto3.Size = new System.Drawing.Size(87, 42);
            this.bto3.TabIndex = 0;
            this.bto3.TabStop = false;
            // 
            // bto2
            // 
            this.bto2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto2.BackgroundImage")));
            this.bto2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bto2.Location = new System.Drawing.Point(119, 172);
            this.bto2.Name = "bto2";
            this.bto2.Size = new System.Drawing.Size(88, 42);
            this.bto2.TabIndex = 0;
            this.bto2.TabStop = false;
            // 
            // bto1
            // 
            this.bto1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bto1.BackgroundImage")));
            this.bto1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bto1.Location = new System.Drawing.Point(35, 172);
            this.bto1.Name = "bto1";
            this.bto1.Size = new System.Drawing.Size(88, 42);
            this.bto1.TabIndex = 0;
            this.bto1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel4.Location = new System.Drawing.Point(0, 461);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(280, 66);
            this.panel4.TabIndex = 2;
            // 
            // btoConf
            // 
            this.btoConf.BackColor = System.Drawing.Color.Transparent;
            this.btoConf.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btoConf.BackgroundImage")));
            this.btoConf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btoConf.Location = new System.Drawing.Point(-73, 281);
            this.btoConf.Name = "btoConf";
            this.btoConf.Size = new System.Drawing.Size(191, 60);
            this.btoConf.TabIndex = 8;
            this.btoConf.TabStop = false;
            this.btoConf.Click += new System.EventHandler(this.btoConf_Click);
            this.btoConf.MouseEnter += new System.EventHandler(this.btoConf_MouseEnter);
            this.btoConf.MouseLeave += new System.EventHandler(this.btoConf_MouseLeave);
            // 
            // frmLoja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1226, 825);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pbClebio);
            this.Controls.Add(this.btoSair);
            this.Controls.Add(this.btoConf);
            this.Controls.Add(this.btoLoja);
            this.Controls.Add(this.btoHome);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmLoja";
            this.Palette = this.kryptonPalette1;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frnLoja";
            ((System.ComponentModel.ISupportInitialize)(this.pbClebio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btoSair)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btoLoja)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btoHome)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bto9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto8)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bto6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto4)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bto3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bto1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btoConf)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPalette1;
        private System.Windows.Forms.PictureBox pbClebio;
        private System.Windows.Forms.PictureBox btoSair;
        private System.Windows.Forms.PictureBox btoLoja;
        private System.Windows.Forms.PictureBox btoHome;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox bto1;
        private System.Windows.Forms.PictureBox bto9;
        private System.Windows.Forms.PictureBox bto8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox bto3;
        private System.Windows.Forms.PictureBox bto2;
        private System.Windows.Forms.PictureBox bto6;
        private System.Windows.Forms.PictureBox bto5;
        private System.Windows.Forms.PictureBox bto4;
        private System.Windows.Forms.PictureBox bto7;
        private System.Windows.Forms.PictureBox btoConf;
    }
}